package com.zbiti.iepe.framework.model;

/**  
* @Title: BaseOrganizationLocationCode.java
* @Package com.zbiti.iepe.framework.model
* @Description: TODO(用一句话描述该文件做什么)
* @author HT  
* @date 2014-3-14 下午2:15:38
*/
public class BaseOrganizationLocationCode
{
	private String areaId;

	public String getAreaId() {
		return areaId;
	}

	public void setAreaId(String areaId) {
		this.areaId = areaId;
	}
}
