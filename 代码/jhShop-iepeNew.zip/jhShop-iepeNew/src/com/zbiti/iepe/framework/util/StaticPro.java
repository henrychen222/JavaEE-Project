package com.zbiti.iepe.framework.util;

/**
 * 静态变量
 * 
 * @author zhaoqi
 * 
 */
public class StaticPro
{
	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_ADD = "A";
	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_DELETE = "D";
	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_MODIFY = "U";

	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_ADD_USER_ROLE = "AUR";
	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_DELETE_USER_ROLE = "DUR";

	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_ADD_USER_DIMENTION = "AUD";
	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_DELETE_USER_DIMENTION = "DUD";

	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_ADD_DIMENTION_TYPE = "ADT";
	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_DELETE_DIMENTION_TYPE = "DDT";
	/**
	 * 权限日志操作
	 */
	public static String PERMISSION_OPR_MODIFY_DIMENTION_TYPE = "MDT";
}
