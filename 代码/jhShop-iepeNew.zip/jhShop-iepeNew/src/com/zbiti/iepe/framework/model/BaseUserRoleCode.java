package com.zbiti.iepe.framework.model;

/**
 * @Title: BaseOrganizationLocationCode.java
 * @Package com.zbiti.iepe.framework.model
 * @Description: TODO
 * @author HT
 * @date 2014-3-14 下午2:15:38
 */
public class BaseUserRoleCode
{
	private String roleTypeCd;

	public String getRoleTypeCd()
	{
		return roleTypeCd;
	}

	public void setRoleTypeCd(String roleTypeCd)
	{
		this.roleTypeCd = roleTypeCd;
	}

}
