package com.zbiti.iepe.framework.dao;

import java.util.List;
import java.util.Map;

public interface MetaDao  {
	public List<Map<String, Object>> getMetaData();
}
