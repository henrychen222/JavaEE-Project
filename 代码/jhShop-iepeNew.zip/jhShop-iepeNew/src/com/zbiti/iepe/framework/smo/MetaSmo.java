package com.zbiti.iepe.framework.smo;

import java.util.List;
import java.util.Map;

public interface MetaSmo {
	public List<Map<String, Object>> getMetaData();
}
