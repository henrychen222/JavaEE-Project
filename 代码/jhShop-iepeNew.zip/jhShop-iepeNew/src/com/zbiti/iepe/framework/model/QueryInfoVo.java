/**
 * 
 */
package com.zbiti.iepe.framework.model;

/**
 *<p></p>
 * @author:y.you
 * 2016年3月31日
 * @version：v1.0
 */
public class QueryInfoVo {

}
