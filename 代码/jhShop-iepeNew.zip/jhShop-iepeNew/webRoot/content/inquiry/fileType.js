function getFliePath(fileType){
	fileType = fileType.toLowerCase();   
	var location = (window.location+'').split('/'); 
	var basePath = location[0]+'//'+location[2]+'/'+location[3];
	var imagePath = basePath+"/common/images/fileType/xlsx.png";
	if(fileType==".xlsx"){
		 imagePath = basePath+"/common/images/fileType/xlsx.png";
	}
	else if(fileType==".xls"){
		 imagePath = basePath+"/common/images/fileType/xls.png";
	}
	else if(fileType==".ppt"){
		 imagePath = basePath+"/common/images/fileType/ppt.png";
	}
	else if(fileType==".doc"){
		 imagePath = basePath+"/common/images/fileType/doc.png";
	}
	else if(fileType==".docx"){
		 imagePath = basePath+"/common/images/fileType/docx.png";
	}
	else if(fileType==".txt"){
		 imagePath = basePath+"/common/images/fileType/txt.png";
	}
	else if(fileType==".exe"){
		 imagePath = basePath+"/common/images/fileType/exe.png";
	}
	else if(fileType==".avi"){
		 imagePath = basePath+"/common/images/fileType/avi.png";
	}
	else if(fileType==".flv"){
		 imagePath = basePath+"/common/images/fileType/flv.png";
	}
	else if(fileType==".gif"){
		 imagePath = basePath+"/common/images/fileType/gif.png";
	}
	else if(fileType==".html"){
		 imagePath = basePath+"/common/images/fileType/html.png";
	}
	else if(fileType==".ics"){
		 imagePath = basePath+"/common/images/fileType/ics.png";
	}
	else if(fileType==".jpg"){
		 imagePath = basePath+"/common/images/fileType/jpg.png";
	}
	else if(fileType==".mp3"){
		 imagePath = basePath+"/common/images/fileType/mp3.png";
	}
	else if(fileType==".mp4"){
		 imagePath = basePath+"/common/images/fileType/mp4.png";
	}
	else if(fileType==".pdf"){
		 imagePath = basePath+"/common/images/fileType/pdf.png";
	}
	else if(fileType==".php"){
		 imagePath = basePath+"/common/images/fileType/php.png";
	}
	else if(fileType==".png"){
		 imagePath = basePath+"/common/images/fileType/png.png";
	}
	else if(fileType==".rar"){
		 imagePath = basePath+"/common/images/fileType/rar.png";
	}
	else if(fileType==".sql"){
		 imagePath = basePath+"/common/images/fileType/sql.png";
	}
	else if(fileType==".xml"){
		 imagePath = basePath+"/common/images/fileType/xml.png";
	}
	else if(fileType==".zip"){
		 imagePath = basePath+"/common/images/fileType/zip.png";
	}else{
	}
	return imagePath;
}