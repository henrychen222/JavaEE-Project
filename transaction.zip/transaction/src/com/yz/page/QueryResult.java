package com.yz.page;

import java.util.List;

@SuppressWarnings("unchecked")
public class QueryResult {
	
	private List list;
	private int totalrecord;
	
	 
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public int getTotalrecord() {
		return totalrecord;
	}
	public void setTotalrecord(int totalrecord) {
		this.totalrecord = totalrecord;
	}
	

}
